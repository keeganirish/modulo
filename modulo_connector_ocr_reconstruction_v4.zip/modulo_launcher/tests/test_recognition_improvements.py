"""Regression tests for connector/OCR recognition improvements."""
import numpy as np
import pytest

from backend.models import PipelineContext
from backend.services import vision_service


def test_decision_ocr_uses_single_line_segmentation(monkeypatch):
    calls = []

    monkeypatch.setattr(vision_service, "preprocess_ocr_candidates", lambda image, shape_type: [image])

    def fake_read_words(image, context, psm, origin):
        calls.append(psm)
        return "num < 0", []

    monkeypatch.setattr(vision_service, "read_words", fake_read_words)
    image = np.full((40, 120), 255, dtype=np.uint8)
    context = PipelineContext()
    text, _, _ = vision_service.read_best_words(image, context, shape_type="decision", return_candidates=True)

    assert text == "num < 0"
    assert 7 in calls  # single-line mode catches short conditions/operators
    assert 6 in calls and 11 in calls  # keep complementary fallback modes


def test_decision_candidate_ranking_rewards_valid_expression():
    candidates = [
        ("NN OY m<00", []),
        ("num < 0", []),
    ]
    text, _, alternatives = vision_service.select_ocr_candidate(candidates, "decision")
    assert text == "num < 0"
    assert any(item["text"] == "NN OY m<00" for item in alternatives)


def test_print_keyword_repair_is_candidate_not_unconditional_rewrite():
    repaired = vision_service._repair_ocr_text('rint "message"', "process")
    assert 'Print "message"' in repaired
    assert vision_service._repair_ocr_text("rint something", "process") == []


def test_output_ocr_repairs_near_miss_common_words_without_touching_identifiers():
    from backend.services.vision_service import _repair_ocr_text

    repaired = _repair_ocr_text('Print "Factorial is no\' Jefined for negative numbers"', "process")
    assert 'Print "Factorial is not defined for negative numbers"' in repaired
    # Unknown identifiers are not silently rewritten to ordinary vocabulary.
    assert _repair_ocr_text("print customer_count", "process") == []


def test_output_candidate_selection_prefers_coherent_repaired_sentence():
    text, _, _ = vision_service.select_ocr_candidate(
        [('Print "Factorial is no\' Jefined for negative numbers"', [])],
        "process",
    )
    assert text == 'Print "Factorial is not defined for negative numbers"'



def test_decision_ocr_adds_enlarged_center_crop(monkeypatch):
    calls = []

    monkeypatch.setattr(vision_service, "preprocess_ocr_candidates", lambda image, shape_type: [image])

    def fake_read_words(image, context, psm, origin):
        calls.append((image.shape, psm, origin))
        # The center crop is upscaled; simulate the better reading it is intended
        # to recover from a large diamond with a small centered label.
        if image.shape[0] < 180 and psm == 7:
            return "num < 0", []
        return "NN OY m<0O", []

    monkeypatch.setattr(vision_service, "read_words", fake_read_words)
    image = np.full((130, 240), 255, dtype=np.uint8)
    text, _, alternatives = vision_service.read_best_words(
        image, PipelineContext(), origin=(100, 200), shape_type="decision", return_candidates=True
    )
    assert any(shape[0] < image.shape[0] * 2 for shape, _, _ in calls)
    assert any(psm == 7 and shape[0] == int(image.shape[0] * .60) * 2 for shape, psm, _ in calls)
    assert text == "num < 0"
    assert any(item["text"] == "NN OY m<0O" for item in alternatives)


def test_terminal_semantics_recovers_occluded_end_arrowhead():
    import cv2
    from backend.config import Settings
    from backend.models import BoundingBox, Node, PipelineContext
    from backend.services.graph_service import GraphService

    source = Node("n1", "process", "Print factorial", BoundingBox(40, 10, 20, 12),
                  polygon=[(40, 10), (60, 10), (60, 22), (40, 22)])
    end = Node("n2", "terminal", "End", BoundingBox(20, 48, 20, 20),
               polygon=[(20, 48), (40, 48), (40, 68), (20, 68)])
    mask = np.zeros((90, 90), dtype=np.uint8)
    # An elbow-shaped connector ending at End. Its arrowhead is deliberately
    # absent, representing the portion lost when node pixels are removed.
    cv2.line(mask, (50, 22), (50, 35), 255, 2)
    cv2.line(mask, (50, 35), (30, 35), 255, 2)
    cv2.line(mask, (30, 35), (30, 48), 255, 2)
    context = PipelineContext(settings=Settings(), elements=[source, end], stroke_mask=mask)
    GraphService().run(context)
    assert any(edge.source == "n1" and edge.target == "n2" for edge in context.graph.edges)
    assert any(item.code == "INFERRED_TERMINAL_DIRECTION" for item in context.diagnostics)


def test_repaired_output_candidate_outranks_ocr_gibberish():
    text, _, alternatives = vision_service.select_ocr_candidate(
        [('Print "Factorial is no\' Jefined for negative numbers"', [])],
        "process",
    )
    assert text == 'Print "Factorial is not defined for negative numbers"'
    assert any("Jefined" in item["text"] for item in alternatives)



def test_instruction_verbs_refine_rectangular_shape_semantics():
    from backend.services.vision_service import infer_instruction_kind

    assert infer_instruction_kind("process", "Input number") == ("input", "Input number")
    assert infer_instruction_kind("process", "Print factorial") == ("output", "Output factorial")
    assert infer_instruction_kind("process", 'Print "Factorial is not defined') == (
        "output", 'Output "Factorial is not defined"'
    )
    assert infer_instruction_kind("process", 'Print "Factorial is not defined"') == (
        "output", 'Output "Factorial is not defined"'
    )
    assert infer_instruction_kind("process", "Calculate factorial") == (
        "process", "Calculate factorial"
    )


def test_aligned_connector_fragments_are_stitched_without_global_closing():
    from backend.models import BoundingBox, Node
    from backend.services.graph_service import bridge_aligned_connector_gaps

    mask = np.zeros((300, 200), dtype=np.uint8)
    # A vertical connector split by a branch label's erased OCR box.
    import cv2
    cv2.line(mask, (80, 30), (80, 100), 255, 5)
    cv2.line(mask, (82, 140), (82, 240), 255, 5)
    node = Node("n1", "process", "A", BoundingBox(20, 10, 20, 20))
    repaired = bridge_aligned_connector_gaps(mask, [node])
    count, labels = cv2.connectedComponents(repaired, connectivity=8)
    upper = labels[80, 80]
    lower = labels[160, 82]
    assert upper != 0 and upper == lower



@pytest.mark.skipif(
    __import__("os").getenv("FLOWCHART_RUN_PIPELINE") != "1",
    reason="set FLOWCHART_RUN_PIPELINE=1 to run OCR-dependent uploaded-diagram regression",
)
def test_uploaded_factorial_flowchart_reconstructs_all_seven_connections():
    from pathlib import Path
    from backend.config import Settings
    from backend.pipeline import analyze

    fixture = Path(__file__).parent / "fixtures" / "flowcharts" / "factorial_curved_connectors.jpg"
    result = analyze(fixture.read_bytes(), filename=fixture.name, settings=Settings())
    actual = {(edge.source, edge.target, edge.label) for edge in result.graph.edges}
    expected = {
        ("n1", "n2", None),
        ("n2", "n3", None),
        ("n3", "n5", "Yes"),
        ("n3", "n4", "No"),
        ("n4", "n6", None),
        ("n5", "n7", None),
        ("n6", "n7", None),
    }
    assert actual == expected
    nodes = {node.id: node for node in result.elements}
    assert nodes["n3"].text == "num < 0"
    assert nodes["n5"].text == 'Output "Factorial is not defined for negative numbers"'
    assert nodes["n2"].type == "input"
    assert nodes["n5"].type == "output"



def test_decision_instruction_preserves_leading_if_for_review():
    from backend.services.vision_service import infer_instruction_kind

    kind, text = infer_instruction_kind("decision", "If number % 2 == 0")
    assert kind == "decision"
    assert text == "If number % 2 == 0"


def test_elbow_branch_gap_uses_narrow_endpoint_not_component_aspect_ratio():
    import cv2
    from backend.models import BoundingBox, Node
    from backend.services.graph_service import bridge_aligned_connector_gaps

    mask = np.zeros((240, 260), dtype=np.uint8)
    # First fragment is an L-shaped connector with a wide overall bbox. Its
    # exposed lower endpoint is narrow and aligned with the second fragment.
    cv2.line(mask, (35, 65), (190, 65), 255, 4)
    cv2.line(mask, (37, 65), (37, 125), 255, 4)
    cv2.line(mask, (37, 165), (37, 220), 255, 4)
    node = Node("n1", "decision", "x > 0", BoundingBox(170, 20, 50, 50),
                polygon=[(195, 20), (220, 45), (195, 70), (170, 45)])
    repaired = bridge_aligned_connector_gaps(mask, [node])
    count, labels = cv2.connectedComponents(repaired, connectivity=8)
    assert count == 2
    assert labels[100, 37] == labels[180, 37] != 0
