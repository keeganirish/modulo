"""Geometry regression tests for imperfect and ambiguous flowchart nodes."""
import cv2
import numpy as np

from backend.services.vision_service import classify_shape


def _largest_contour(image):
    contours, _ = cv2.findContours(image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    return max(contours, key=cv2.contourArea)


def test_rotated_process_rectangle_remains_process():
    image = np.zeros((240, 300), np.uint8)
    points = cv2.boxPoints(((150, 120), (150, 68), 27)).astype(np.int32)
    cv2.fillPoly(image, [points], 255)
    assert classify_shape(_largest_contour(image), image.shape[1]) == "process"


def test_rounded_terminal_is_classified_as_terminal():
    image = np.zeros((180, 300), np.uint8)
    cv2.rectangle(image, (70, 45), (230, 135), 255, -1)
    cv2.ellipse(image, (70, 90), (28, 45), 0, 90, 270, 255, -1)
    cv2.ellipse(image, (230, 90), (28, 45), 0, -90, 90, 255, -1)
    assert classify_shape(_largest_contour(image), image.shape[1]) == "terminal"


def test_small_circle_is_connector():
    image = np.zeros((180, 240), np.uint8)
    cv2.circle(image, (120, 90), 20, 255, -1)
    assert classify_shape(_largest_contour(image), image.shape[1]) == "connector"


def test_ambiguous_triangle_is_not_forced_into_known_type():
    image = np.zeros((180, 240), np.uint8)
    cv2.fillPoly(image, [np.array([[120, 35], [195, 140], [45, 140]], np.int32)], 255)
    assert classify_shape(_largest_contour(image), image.shape[1]) == "unknown"


def test_low_resolution_parallelogram_keeps_data_class():
    image = np.zeros((100, 180), np.uint8)
    cv2.fillPoly(image, [np.array([[35, 25], [135, 25], [145, 70], [45, 70]], np.int32)], 255)
    assert classify_shape(_largest_contour(image), image.shape[1]) == "data"
