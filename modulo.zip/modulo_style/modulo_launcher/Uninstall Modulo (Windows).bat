@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0installer\uninstall-windows.ps1"
pause
